/** @jsxImportSource @emotion/react */
import * as s from "./styles";


function MyPageCategory() {
    
    
    return (<div>



    </div>);
}

export default MyPageCategory;